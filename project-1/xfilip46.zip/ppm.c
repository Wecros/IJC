#include "ppm.h"
#include "eratosthenes.h"

struct ppm * ppm_read(const char * filename) {
    
}

void ppm_free(struct ppm *p) {

}