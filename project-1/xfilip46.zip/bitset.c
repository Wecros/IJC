#include "bitset.h"

#ifdef USE_INLINE
extern bitset_free; 
extern bitset_size; 
extern bitset_setbit;
extern bitset_getbit; 
#endif 